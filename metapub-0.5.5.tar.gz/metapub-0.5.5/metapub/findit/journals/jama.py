from __future__ import absolute_import, unicode_literals

jama_journals = (
    'AMA Arch Intern Med',
    'Arch Dermatol',
    'Arch Gen Psychiatry',
    'Arch Neurol',
    'Arch Ophthalmol',
    'Arch Surg',
    'JAMA',
    'JAMA Dermatol',
    'JAMA Facial Plast Surg',
    'JAMA Intern Med',
    'JAMA Neurol',
    'JAMA Oncol',
    'JAMA Ophthalmol',
    'JAMA Otolaryngol Head Neck Surg',
    'JAMA Pediatr',
    'JAMA Psychiatry',
    'JAMA Surg',
)
