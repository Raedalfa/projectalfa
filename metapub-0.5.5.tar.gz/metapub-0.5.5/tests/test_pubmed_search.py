import unittest

from metapub import PubMedFetcher

class TestPubmedSearch(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass
